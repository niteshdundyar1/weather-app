package com.innovect.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.innovect.exception.ForecastException;
import com.innovect.exception.NoForecastResultFound;
import com.innovect.model.ForecastModel;


@Service
public class WeatherForecast {

	@Autowired
	ForecastModel forecastModel;

	@Value("${weather.url}")
	private String URL;
	
	//private static final String URL = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/forecast";

	/**
	 * This method is responsible to call the weather service API and return the response.
	 * @param weatherLocation
	 * @return
	 * @throws ForecastException
	 */
	public ForecastModel getWeatherForcastDetails(String weatherLocation) throws ForecastException{


		CloseableHttpResponse response = null;   

		JSONObject jsonWeatherForecast = null;
		try {
			//set up the end point
			URIBuilder builder = buildURL(weatherLocation);

			HttpGet get = new HttpGet(builder.build());

			CloseableHttpClient httpclient = HttpClients.createDefault();

			response = httpclient.execute(get);

			if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
				throw new ForecastException("Bad response, status code: " + response.getStatusLine().getStatusCode());
			}

			HttpEntity entity = response.getEntity();
			if (entity != null) {
				String rawResult=EntityUtils.toString(entity, Charset.forName("utf-8"));
				jsonWeatherForecast = new JSONObject(rawResult);
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		finally {
			try {
				response.close();
			} catch (IOException e) {
				throw new NoForecastResultFound("No weather forecast fond for :"+ weatherLocation);
			}
		}

		if (jsonWeatherForecast==null) {
			throw new NoForecastResultFound("No weather forecast data returned");
		} else {
			boolean errorFound = false;
			try {
				//Check the weather service response, if it contains error code then throw the exception
				if(jsonWeatherForecast.get("errorCode") != null) {
					errorFound = true;
				}
			} catch (Exception e) {
			}
			
			if(errorFound) {
				throw new ForecastException(jsonWeatherForecast.get("message").toString());
			}
		}
		
		//Parse the weather service response in JSON
		try {
			JSONObject location=jsonWeatherForecast.getJSONObject("location");
			JSONArray values=location.getJSONArray("values");

			JSONObject forecastValue = values.getJSONObject(1);

			ZonedDateTime datetime=ZonedDateTime.parse( forecastValue.getString("datetimeStr"), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
			String tomorrowDate = datetime.format(DateTimeFormatter.ISO_LOCAL_DATE);

			double maximumTemp = forecastValue.getDouble("maxt");
			double minimumTemp=forecastValue.getDouble("mint");

			//Set the JSON response to model
			forecastModel.setAddress(location.getString("address"));
			forecastModel.setDate(tomorrowDate);
			forecastModel.setMaxTemp(maximumTemp);
			forecastModel.setMinTemp(minimumTemp);
		} catch (Exception e) {
		}
		
		return forecastModel;

	}

	/**
	 * This method is responsible to build the URI
	 * @param location
	 * @return
	 * @throws URISyntaxException
	 */
	private URIBuilder buildURL(String location) throws URISyntaxException {
		URIBuilder builder = new URIBuilder(URL);
		builder.setParameter("aggregateHours", "24")
		.setParameter("contentType", "json")
		.setParameter("unitGroup", "metric")
		.setParameter("locationMode", "single")
		.setParameter("key", "1PYNQ6AWUDJE9AFERDCHJHSXK")
		.setParameter("locations", location);
		return builder;
	}
}
