package com.innovect.exception;

public class NoForecastResultFound extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public NoForecastResultFound(String s){
		super(s);
	}

}
