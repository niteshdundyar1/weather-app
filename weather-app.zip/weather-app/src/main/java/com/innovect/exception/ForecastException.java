package com.innovect.exception;

public class ForecastException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ForecastException(String s){
		super(s);
	}
}
