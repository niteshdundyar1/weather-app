package com.innovect.model;

import java.util.Date;
/**
 * Error model to throw the customer error details
 * @author Nitesh
 *
 */
public class ErrorDetails {

	@SuppressWarnings("unused")
	private Date timestamp;
	@SuppressWarnings("unused")
	private String message;
	@SuppressWarnings("unused")
	private String details;

	public ErrorDetails(Date timestamp, String message, String details) {
		super();
		this.timestamp = timestamp;
		this.message = message;
		this.details = details;
	}
}
