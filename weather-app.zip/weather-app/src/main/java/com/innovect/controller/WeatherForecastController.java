package com.innovect.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovect.model.ForecastModel;
import com.innovect.service.WeatherForecast;

@RestController
public class WeatherForecastController {

	@Autowired
	WeatherForecast weatherForecast;

	//http://localhost:8084/weatherDetail/85001
	@RequestMapping(value="/weatherDetail/{zip}")
	public ForecastModel getWeaterDetail(@PathVariable String zip) {

		//Default location country only USA
		String weatherLocation = zip + ",USA";
		return weatherForecast.getWeatherForcastDetails(weatherLocation);

	}

	@RequestMapping(value="/hello")
	public String hello() {
		return "hello app!";
	}
}
