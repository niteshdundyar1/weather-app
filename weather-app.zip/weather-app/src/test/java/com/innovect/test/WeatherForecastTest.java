package com.innovect.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;

import com.innovect.controller.WeatherForecastController;
import com.innovect.model.ErrorDetails;
import com.innovect.model.ForecastModel;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class WeatherForecastTest {

	@Autowired
	private WeatherForecastController wfc;
	
	@Test
	public void contextLoads() throws Exception {
		assertThat(wfc).isNotNull();
	}
	
	@LocalServerPort
	private int port;
	
	@Autowired
	private TestRestTemplate restTemplate;
	
	/**
	 * Positive scenario
	 * @throws Exception
	 */
	@Test
	public void greetingShouldReturnCorrectData() throws Exception {
		ForecastModel fm = this.restTemplate.getForObject("http://localhost:" + port + "/weatherDetail/85343",
				ForecastModel.class);
		assertThat(fm.getAddress()).contains("85343");
	}
	
	/**
	 * Negative scenario
	 * @throws Exception
	 */
	@Test
	public void greetingShouldReturnError() throws Exception {
		ErrorDetails ed = this.restTemplate.getForObject("http://localhost:" + port + "/weatherDetail/00000",
				ErrorDetails.class);
		assertThat(ed).isNotNull();
	}
	
}
